//
//  aextra.swift
//  cookingmama
//
//  Created by Andrew Park on 2/17/24.
//

import Foundation
//var advancedSettingsView: some View {
//    #if os(iOS)
//        NavigationView {
//            settingsForm
//                .navigationBarTitleDisplayMode(.inline)
//        }
//    #else
//        VStack {
//            Text("Decoding Options")
//                .font(.title2)
//                .padding()
//            settingsForm
//                .frame(minWidth: 500, minHeight: 500)
//        }
//    #endif
//}
//
//var settingsForm: some View {
//    List {
//        HStack {
//            Text("Show Timestamps")
//            InfoButton("Toggling this will include/exclude timestamps in both the UI and the prefill tokens.\nEither <|notimestamps|> or <|0.00|> will be forced based on this setting unless \"Prompt Prefill\" is de-selected.")
//            Spacer()
//            Toggle("", isOn: $enableTimestamps)
//        }
//        .padding(.horizontal)
//
//        HStack {
//            Text("Special Characters")
//            InfoButton("Toggling this will include/exclude special characters in the transcription text.")
//            Spacer()
//            Toggle("", isOn: $enableSpecialCharacters)
//        }
//        .padding(.horizontal)
//
//        HStack {
//            Text("Prompt Prefill")
//            InfoButton("When Prompt Prefill is on, it will force the task, language, and timestamp tokens in the decoding loop. \nToggle it off if you'd like the model to generate those tokens itself instead.")
//            Spacer()
//            Toggle("", isOn: $enablePromptPrefill)
//        }
//        .padding(.horizontal)
//
//        HStack {
//            Text("Cache Prefill")
//            InfoButton("When Cache Prefill is on, the decoder will try to use a lookup table of pre-computed KV caches instead of computing them during the decoding loop. \nThis allows the model to skip the compute required to force the initial prefill tokens, and can speed up inference")
//            Spacer()
//            Toggle("", isOn: $enableCachePrefill)
//        }
//        .padding(.horizontal)
//
//        VStack {
//            Text("Starting Temperature:")
//            HStack {
//                Slider(value: $temperatureStart, in: 0...1, step: 0.1)
//                Text(temperatureStart.formatted(.number))
//                InfoButton("Controls the initial randomness of the decoding loop token selection.\nA higher temperature will result in more random choices for tokens, and can improve accuracy.")
//            }
//        }
//        .padding(.horizontal)
//
//        VStack {
//            Text("Max Fallback Count:")
//            HStack {
//                Slider(value: $fallbackCount, in: 0...5, step: 1)
//                Text(fallbackCount.formatted(.number))
//                    .frame(width: 30)
//                InfoButton("Controls how many times the decoder will fallback to a higher temperature if any of the decoding thresholds are exceeded.\n Higher values will cause the decoder to run multiple times on the same audio, which can improve accuracy at the cost of speed.")
//            }
//        }
//        .padding(.horizontal)
//
//        VStack {
//            Text("Compression Check Tokens")
//            HStack {
//                Slider(value: $compressionCheckWindow, in: 0...100, step: 5)
//                Text(compressionCheckWindow.formatted(.number))
//                    .frame(width: 30)
//                InfoButton("Amount of tokens to use when checking for whether the model is stuck in a repetition loop.\nRepetition is checked by using zlib compressed size of the text compared to non-compressed value.\n Lower values will catch repetitions sooner, but too low will miss repetition loops of phrases longer than the window.")
//            }
//        }
//        .padding(.horizontal)
//
//        VStack {
//            Text("Max Tokens Per Loop")
//            HStack {
//                Slider(value: $sampleLength, in: 0...Double(min(whisperKit?.textDecoder.kvCacheMaxSequenceLength ?? WhisperKit.maxTokenContext, WhisperKit.maxTokenContext)), step: 10)
//                Text(sampleLength.formatted(.number))
//                    .frame(width: 30)
//                InfoButton("Maximum number of tokens to generate per loop.\nCan be lowered based on the type of speech in order to further prevent repetition loops from going too long.")
//            }
//        }
//        .padding(.horizontal)
//
//        VStack {
//            Text("Silence Threshold")
//            HStack {
//                Slider(value: $silenceThreshold, in: 0...1, step: 0.05)
//                Text(silenceThreshold.formatted(.number))
//                    .frame(width: 30)
//                InfoButton("Relative silence threshold for the audio. \n Baseline is set by the quietest 100ms in the previous 2 seconds.")
//            }
//        }
//        .padding(.horizontal)
//    }
//    .navigationTitle("Decoding Options")
//    .toolbar(content: {
//        ToolbarItem {
//            Button {
//                showAdvancedOptions = false
//            } label: {
//                Label("Done", systemImage: "xmark.circle.fill")
//                    .foregroundColor(.primary)
//            }
//        }
//    })
//}
//
//struct InfoButton: View {
//    var infoText: String
//    @State private var showInfo = false
//
//    init(_ infoText: String) {
//        cookVM.infoText = infoText
//    }
//
//    var body: some View {
//        Button(action: {
//            cookVM.showInfo = true
//        }) {
//            Image(systemName: "info.circle")
//                .foregroundColor(.blue)
//        }
//        .popover(isPresented: $showInfo) {
//            Text(infoText)
//                .padding()
//        }
//        .buttonStyle(BorderlessButtonStyle())
//    }
//}
