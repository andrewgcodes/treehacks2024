//
//  ContentView.swift
//  cookingmama
//
//  Created by Andrew Park on 2/17/24.
//
//
//  ContentView.swift
//  newworld
//
//  Created by Andrew Park on 2/16/24.
//
import AVFoundation
import ElevenlabsSwift
import RealityKit
import SwiftUI
import WhisperKit

struct Message: Identifiable {
    let id = UUID()
    let role: String
    let content: String
    

}


struct ContentView: View {
    @Environment(\.openImmersiveSpace) var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) var dismissImmersiveSpace

    var body: some View {
        VStack {
            

            WhisperView()
        }
        .background(.pink.opacity(0.125))
    }

}

#Preview(body: {
    ContentView()
})
