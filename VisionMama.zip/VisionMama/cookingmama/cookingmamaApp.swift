//
//  cookingmamaApp.swift
//  cookingmama
//
//  Created by Andrew Park on 2/17/24.
//

import SwiftUI

@main
struct cookingmamaApp: App {
    var cookVM: CookingVM = .init()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(cookVM)
        }
    }
}
