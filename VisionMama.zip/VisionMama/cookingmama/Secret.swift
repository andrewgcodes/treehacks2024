//
//  Secret.swift
//  cookingmama
//
//  Created by Andrew Park on 2/17/24.
//

enum Secret {
    static let whisperKey = ""
    static let gptKey = ""
    static let elevenlabsKey = ""
}